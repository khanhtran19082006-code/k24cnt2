using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using TQK_Lesson4.Models;

namespace TQK_Lesson4.Controllers
{
    public class ProfilesController : Controller
    {
        private static readonly List<Person> _people = new List<Person>
        {
            new Person { Id = 1, FullName = "Nguyễn Văn An", Email = "an.nguyen@example.com", Address = "Hanoi, Vietnam", Phone = "0912345678", Bio = "Kỹ sư phần mềm đam mê công nghệ và du lịch.", Gender = "Nam", Birthday = new DateTime(1995,5,1), AvatarUrl = "https://i.pravatar.cc/400?img=1" },
            new Person { Id = 2, FullName = "Trần Thị Bích", Email = "bich.tran@example.com", Address = "Da Nang, Vietnam", Phone = "0987654321", Bio = "Chuyên viên Marketing sáng tạo và yêu thích nghệ thuật.", Gender = "Nữ", Birthday = new DateTime(1992,3,12), AvatarUrl = "https://i.pravatar.cc/400?img=2" },
            new Person { Id = 3, FullName = "Lê Hoàng Nam", Email = "nam.le@example.com", Address = "Ho Chi Minh City, Vietnam", Phone = "0977123456", Bio = "UI/UX Designer tự do, thích nhiếp ảnh và cà phê.", Gender = "Nam", Birthday = new DateTime(1990,7,23), AvatarUrl = "https://i.pravatar.cc/400?img=3" },
            new Person { Id = 4, FullName = "Phạm Minh Châu", Email = "chau.pham@example.com", Address = "Nha Trang, Vietnam", Phone = "0945678901", Bio = "Quản lý dự án, quan tâm đến khởi nghiệp và công nghệ.", Gender = "Nam", Birthday = new DateTime(1993,11,5), AvatarUrl = "https://i.pravatar.cc/400?img=4" },
            new Person { Id = 5, FullName = "Hoàng Quốc Dũng", Email = "dung.hoang@example.com", Address = "56 Đường Quang Trung, TP. Nha Trang, Khánh Hòa", Phone = "0945678901", Bio = "Chuyên viên phân tích dữ liệu, thích chơi bóng rổ.", Gender = "Nam", Birthday = new DateTime(1997,12,5), AvatarUrl = "https://i.pravatar.cc/400?img=5" }
        };

        public IActionResult Index()
        {
            return View(_people);
        }

        public IActionResult Details(int id)
        {
            var person = _people.FirstOrDefault(p => p.Id == id);
            if (person == null) return NotFound();
            return View(person);
        }
    }
}
