using System;

namespace TQK_Lesson4.Models
{
    public class Person
    {
        public int Id { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }
        public string Bio { get; set; }
        public string Gender { get; set; }
        public DateTime Birthday { get; set; }
        public string AvatarUrl { get; set; }
    }
}
