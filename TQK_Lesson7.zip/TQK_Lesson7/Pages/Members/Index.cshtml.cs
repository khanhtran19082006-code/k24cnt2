using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;
using System.Linq;
using TQK_Lesson7.Models;

namespace TQK_Lesson7.Pages.Members
{
    public class IndexModel : PageModel
    {
        public List<Member> Members { get; set; }
        public Member SelectedMember { get; set; }
        public void OnGet(string id)
        {
            Members = new List<Member>
            {
                new Member{ MemberId = "4cf7807a-9cde-496d-af15-9e2e7c1e5345", UserName = "khanhtq", FullName = "Trần Quốc Khánh", Email = "chungtrinhj@example.com", Password = "password123" },
                new Member{ MemberId = "43376abe-f763-4d32-b141-da49da5f20e9", UserName = "tranthibinh", FullName = "Trần Thị Bình", Email = "tranthibinh@example.com", Password = "pwtran" },
                new Member{ MemberId = "345ce587-91da-4722-9b27-eeacbc8bbeed", UserName = "levancuong", FullName = "Lê Văn Cường", Email = "levancuong@example.com", Password = "pwle" },
                new Member{ MemberId = "2fcec71c-7fab-4c8f-9185-fa5b4d7163d4", UserName = "phamthiduyen", FullName = "Phạm Thị Duyên", Email = "phamthiduyen@example.com", Password = "pwpham" },
                new Member{ MemberId = "1fed83c8-299e-4783-b1ca-ec82d6c2c1c5", UserName = "hoangminhduc", FullName = "Hoàng Minh Đức", Email = "hoangminhduc@example.com", Password = "pwhoang" }
            };

            SelectedMember = string.IsNullOrEmpty(id) ? Members.FirstOrDefault() : Members.FirstOrDefault(m => m.MemberId == id) ?? Members.FirstOrDefault();
        }
    }
}
