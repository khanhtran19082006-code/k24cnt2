using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using TQK_Lesson7.Models;

namespace TQK_Lesson7.Pages.Members
{
    public class CreateModel : PageModel
    {
        [BindProperty]
        public Member Member { get; set; }

        public void OnGet()
        {
            Member = new Member
            {
                MemberId = System.Guid.NewGuid().ToString()
            };
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid) return Page();

            // No persistence in this sample; pass via TempData to Details page
            TempData["MemberId"] = Member.MemberId;
            TempData["UserName"] = Member.UserName;
            TempData["Password"] = Member.Password;
            TempData["FullName"] = Member.FullName;
            TempData["Email"] = Member.Email;

            return RedirectToPage("/Members/Details");
        }
    }
}
