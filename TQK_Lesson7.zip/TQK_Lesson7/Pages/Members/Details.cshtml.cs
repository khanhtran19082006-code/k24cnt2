using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TQK_Lesson7.Pages.Members
{
    public class DetailsModel : PageModel
    {
        public string MemberId { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }

        public void OnGet()
        {
            MemberId = TempData["MemberId"] as string ?? (Request.Query["id"].ToString() ?? System.Guid.NewGuid().ToString());
            UserName = TempData["UserName"] as string ?? "khanhtq";
            Password = TempData["Password"] as string ?? "password123";
            FullName = TempData["FullName"] as string ?? "Trần Quốc Khánh";
            Email = TempData["Email"] as string ?? "tqk@example.com";
        }
    }
}
q