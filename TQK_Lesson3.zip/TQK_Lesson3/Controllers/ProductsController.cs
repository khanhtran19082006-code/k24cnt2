using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using TQK_Lesson3.Models;

namespace TQK_Lesson3.Controllers
{
    public class ProductsController : Controller
    {
        public IActionResult Index()
        {
            var items = new List<Product>
            {
                new Product{ Id = "TVC-MB-001", Name = "iPhone 15 Pro Max 256GB", Year=2023, Price=29990000 },
                new Product{ Id = "TVC-MB-002", Name = "Samsung Galaxy S24 Ultra 512GB", Year=2024, Price=31490000 },
                new Product{ Id = "TVC-MB-003", Name = "Xiaomi 14 Ultra 5G", Year=2024, Price=27990000 },
                new Product{ Id = "TVC-MB-004", Name = "Google Pixel 8 Pro 128GB", Year=2023, Price=21500000 },
                new Product{ Id = "TVC-MB-005", Name = "OPPO Find N3 Flip 256GB", Year=2023, Price=19990000 },
                new Product{ Id = "TVC-MB-006", Name = "Samsung Galaxy Z Fold5 512GB", Year=2023, Price=34990000 },
                new Product{ Id = "TVC-MB-007", Name = "iPad Pro M4 11-inch Wi‑Fi 256GB", Year=2024, Price=28990000 },
                new Product{ Id = "TVC-MB-008", Name = "Samsung Galaxy Tab S9 Ultra", Year=2023, Price=25490000 },
                new Product{ Id = "TVC-MB-009", Name = "ASUS ROG Phone 8 Pro 512GB", Year=2024, Price=28490000 },
                new Product{ Id = "TVC-MB-010", Name = "Vivo X100 Pro 5G 256GB", Year=2024, Price=22990000 }
            };

            return View(items);
        }
    }
}
