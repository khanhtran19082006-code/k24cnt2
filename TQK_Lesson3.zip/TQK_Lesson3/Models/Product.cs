namespace TQK_Lesson3.Models
{
    public class Product
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public int Year { get; set; }
        public decimal Price { get; set; }
    }
}
